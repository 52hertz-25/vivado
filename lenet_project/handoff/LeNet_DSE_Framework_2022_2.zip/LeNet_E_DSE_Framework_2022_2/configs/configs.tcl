# E owns the experimental choices. Set enabled to 1 only after defining a real variant.
set dse_configs [list \
    [dict create id fp32_baseline enabled 1 description "verified FP32 baseline" \
        source_cpp "src/lenet_conv.cpp" top_name "lenet_full_top" clock_ns 10.0 \
        cflags "" directives "directives/baseline.tcl" run_csim 1 run_cosim 0 export_ip 0] \
    [dict create id candidate_pipeline enabled 0 description "E: choose loop(s) and pipeline" \
        source_cpp "src/lenet_conv.cpp" top_name "lenet_full_top" clock_ns 10.0 \
        cflags "" directives "directives/candidate_pipeline.tcl" run_csim 1 run_cosim 0 export_ip 0] \
    [dict create id candidate_custom enabled 0 description "E: bit width / PE / unroll variant" \
        source_cpp "variants/candidate_custom/lenet_conv.cpp" top_name "lenet_full_top" clock_ns 10.0 \
        cflags "" directives "directives/candidate_custom.tcl" run_csim 1 run_cosim 0 export_ip 0] \
]
