# E 成员交接清单

- [ ] 在纯英文路径解压本包
- [ ] 用 Vitis HLS 2022.2 Command Prompt 跑通 `fp32_baseline`
- [ ] 确认输出与 `results/verified_baseline.csv` 数量级一致
- [ ] 定义至少 3 个真正不同的候选方案
- [ ] 每个候选完成 C 仿真与精度记录
- [ ] 汇总 HLS 延迟和资源
- [ ] 选择 1–2 个 Pareto 候选进入 Vivado
- [ ] 补录 post-route 时序、资源、功耗
- [ ] 形成 Pareto 图和最终选择理由

建议 E 在汇报中负责：实验变量设计、自动化 DSE 方法、Pareto 分析、最终优化方案选择，以及优化前后量化对比。
