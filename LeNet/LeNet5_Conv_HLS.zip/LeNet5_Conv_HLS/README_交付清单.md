# 成员 C：LeNet-5 Conv1/Conv2 HLS 交付清单

## 交付结论

- 平台：Vivado HLS 2019.1，目标器件 `xc7z020-clg400-1`，目标时钟周期 10 ns。
- Conv1、Conv2 的 C Simulation、C Synthesis、Verilog RTL Co-Simulation 全部通过。
- Conv1/Pool1 最大绝对误差为 `9.53674316e-07`；Conv2 最大绝对误差为 `3.25870514e-03`；Pool2 最大绝对误差为 `1.43361092e-03`。
- HLS 估计时钟周期均为 8.750 ns，满足 10 ns 目标。
- 当前为浮点、串行、未流水化基线，供成员 D 做 PIPELINE、UNROLL、ARRAY_PARTITION 与 PE 并行优化对照。

## 目录说明

```text
model/                         Conv1/Conv2 复现所需输入、权重与黄金特征图
member_c_conv_hls/include/     接口、尺寸和数据类型定义
member_c_conv_hls/src/         5x5窗口、MAC、Conv1/Conv2实现
member_c_conv_hls/tb/          CSim/CoSim测试平台和NPY读取器
member_c_conv_hls/results/     C仿真、HLS综合和RTL协同仿真原始报告
member_c_conv_hls/generated_rtl/ Conv1、Conv2综合生成的Verilog RTL
member_c_conv_hls/docs/        成员C阶段报告
member_c_conv_hls/run_hls.tcl  Vivado HLS 2019.1自动流程
```

## 复现方法

将 `model` 与 `member_c_conv_hls` 保持同级，使用纯英文路径。在 PowerShell 中执行：

```powershell
Set-Location 'D:\lenet_project\member_c_conv_hls'
& 'E:\Vivado\Vivado\2019.1\bin\vivado_hls.bat' -f '.\run_hls.tcl'
```

安装路径不同的电脑需要修改第二行中的 `vivado_hls.bat` 路径。

## 已知限制

1. 只验证了成员 B 提供的一个标签为 7 的样本及其中间特征图，不能据此宣称 MNIST 分类准确率达到 90%。
2. 当前数据类型为 `float`，定点量化需由成员 F 给出格式后重新回归。
3. 当前未做流水化和循环展开，综合报告的 Pipeline Type 为 `none`。
4. Vivado HLS 2019.1 的 IP 打包受 AMD/Xilinx AR 76960 Y2K22 时间戳溢出影响。安装官方 `y2k22_patch-1.2` 后，将 `run_hls.tcl` 中 `export_ip` 改为 `1` 即可打包IP。

## 交接对象

- 成员 D：使用当前源码、测试平台和综合数据作为性能优化基线。
- 成员 E：使用包内 `member_c_conv_hls/generated_rtl`；安装Y2K22补丁后打包IP并完成最终Vivado实现报告。
- 成员 F：修改 `include/lenet_conv.h` 中的 `data_t` 与 `weight_t`，完成定点回归。
