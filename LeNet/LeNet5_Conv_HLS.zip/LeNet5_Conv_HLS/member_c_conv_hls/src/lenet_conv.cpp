#include "lenet_conv.h"

namespace lenet {
namespace {

template <int IN_H, int IN_W>
void generate_window_5x5(
    const data_t *input,
    int input_channel,
    int output_row,
    int output_col,
    data_t window[KERNEL_ELEMS]) {
#pragma HLS INLINE

WINDOW_ROW:
    for (int kernel_row = 0; kernel_row < KERNEL_SIZE; ++kernel_row) {
    WINDOW_COL:
        for (int kernel_col = 0; kernel_col < KERNEL_SIZE; ++kernel_col) {
            const int input_index =
                (input_channel * IN_H + output_row + kernel_row) * IN_W +
                output_col + kernel_col;
            window[kernel_row * KERNEL_SIZE + kernel_col] = input[input_index];
        }
    }
}

data_t mac_5x5(
    const data_t window[KERNEL_ELEMS],
    const weight_t kernel[KERNEL_ELEMS],
    data_t accumulator) {
#pragma HLS INLINE

MAC_LOOP:
    for (int index = 0; index < KERNEL_ELEMS; ++index) {
        accumulator += window[index] * kernel[index];
    }
    return accumulator;
}

template <int IN_C, int IN_H, int IN_W, int OUT_C>
void conv5x5_valid(
    const data_t input[IN_C * IN_H * IN_W],
    const weight_t weights[OUT_C * IN_C * KERNEL_ELEMS],
    data_t output[OUT_C * (IN_H - 4) * (IN_W - 4)]) {
    const int out_h = IN_H - KERNEL_SIZE + 1;
    const int out_w = IN_W - KERNEL_SIZE + 1;

OUTPUT_CHANNEL:
    for (int output_channel = 0; output_channel < OUT_C; ++output_channel) {
    OUTPUT_ROW:
        for (int output_row = 0; output_row < out_h; ++output_row) {
        OUTPUT_COL:
            for (int output_col = 0; output_col < out_w; ++output_col) {
                data_t accumulator = 0.0f;

            INPUT_CHANNEL:
                for (int input_channel = 0; input_channel < IN_C;
                     ++input_channel) {
                    data_t window[KERNEL_ELEMS];
                    generate_window_5x5<IN_H, IN_W>(
                        input,
                        input_channel,
                        output_row,
                        output_col,
                        window);

                    const int kernel_base =
                        (output_channel * IN_C + input_channel) * KERNEL_ELEMS;
                    accumulator =
                        mac_5x5(window, &weights[kernel_base], accumulator);
                }

                const int output_index =
                    (output_channel * out_h + output_row) * out_w + output_col;
                output[output_index] = accumulator;
            }
        }
    }
}

template <int CHANNELS, int IN_H, int IN_W>
void relu_maxpool_2x2(
    const data_t input[CHANNELS * IN_H * IN_W],
    data_t output[CHANNELS * (IN_H / 2) * (IN_W / 2)]) {
    const int out_h = IN_H / 2;
    const int out_w = IN_W / 2;

POOL_CHANNEL:
    for (int channel = 0; channel < CHANNELS; ++channel) {
    POOL_ROW:
        for (int output_row = 0; output_row < out_h; ++output_row) {
        POOL_COL:
            for (int output_col = 0; output_col < out_w; ++output_col) {
                data_t maximum = 0.0f;  // ReLU is fused before max pooling.

            POOL_KERNEL_ROW:
                for (int kernel_row = 0; kernel_row < 2; ++kernel_row) {
                POOL_KERNEL_COL:
                    for (int kernel_col = 0; kernel_col < 2; ++kernel_col) {
                        const int input_row = output_row * 2 + kernel_row;
                        const int input_col = output_col * 2 + kernel_col;
                        const int input_index =
                            (channel * IN_H + input_row) * IN_W + input_col;
                        const data_t value = input[input_index];
                        if (value > maximum) {
                            maximum = value;
                        }
                    }
                }

                const int output_index =
                    (channel * out_h + output_row) * out_w + output_col;
                output[output_index] = maximum;
            }
        }
    }
}

}  // namespace
}  // namespace lenet

extern "C" void lenet_conv1_top(
    const lenet::data_t input[lenet::INPUT_ELEMS],
    const lenet::weight_t weights[lenet::CONV1_WEIGHT_ELEMS],
    lenet::data_t output[lenet::CONV1_OUT_ELEMS]) {
#pragma HLS INTERFACE m_axi port=input offset=slave bundle=gmem0 depth=1024
#pragma HLS INTERFACE m_axi port=weights offset=slave bundle=gmem1 depth=150
#pragma HLS INTERFACE m_axi port=output offset=slave bundle=gmem2 depth=4704
#pragma HLS INTERFACE s_axilite port=input bundle=control
#pragma HLS INTERFACE s_axilite port=weights bundle=control
#pragma HLS INTERFACE s_axilite port=output bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    lenet::conv5x5_valid<
        lenet::INPUT_C, lenet::INPUT_H, lenet::INPUT_W, lenet::CONV1_OUT_C>(
        input, weights, output);
}

extern "C" void lenet_conv2_top(
    const lenet::data_t input[lenet::POOL1_OUT_ELEMS],
    const lenet::weight_t weights[lenet::CONV2_WEIGHT_ELEMS],
    lenet::data_t output[lenet::CONV2_OUT_ELEMS]) {
#pragma HLS INTERFACE m_axi port=input offset=slave bundle=gmem0 depth=1176
#pragma HLS INTERFACE m_axi port=weights offset=slave bundle=gmem1 depth=2400
#pragma HLS INTERFACE m_axi port=output offset=slave bundle=gmem2 depth=1600
#pragma HLS INTERFACE s_axilite port=input bundle=control
#pragma HLS INTERFACE s_axilite port=weights bundle=control
#pragma HLS INTERFACE s_axilite port=output bundle=control
#pragma HLS INTERFACE s_axilite port=return bundle=control

    lenet::conv5x5_valid<
        lenet::POOL1_OUT_C,
        lenet::POOL1_OUT_H,
        lenet::POOL1_OUT_W,
        lenet::CONV2_OUT_C>(
        input, weights, output);
}

namespace lenet {

void lenet_relu_pool1(
    const data_t input[CONV1_OUT_ELEMS],
    data_t output[POOL1_OUT_ELEMS]) {
    relu_maxpool_2x2<CONV1_OUT_C, CONV1_OUT_H, CONV1_OUT_W>(input, output);
}

void lenet_relu_pool2(
    const data_t input[CONV2_OUT_ELEMS],
    data_t output[POOL2_OUT_ELEMS]) {
    relu_maxpool_2x2<CONV2_OUT_C, CONV2_OUT_H, CONV2_OUT_W>(input, output);
}

}  // namespace lenet
