#include "lenet_conv.h"
#include "npy_reader.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

std::string join_path(const std::string &root, const std::string &relative) {
    if (root.empty()) {
        return relative;
    }
    const char last = root[root.size() - 1];
    if (last == '/' || last == '\\') {
        return root + relative;
    }
    return root + "/" + relative;
}

std::vector<float> load_text_floats(
    const std::string &path,
    std::size_t expected_count) {
    std::ifstream stream(path.c_str());
    if (!stream) {
        throw std::runtime_error("Cannot open text data: " + path);
    }

    std::vector<float> values;
    float value = 0.0f;
    while (stream >> value) {
        values.push_back(value);
    }
    if (values.size() != expected_count) {
        throw std::runtime_error(
            "Unexpected element count in " + path + ": got " +
            std::to_string(values.size()) + ", expected " +
            std::to_string(expected_count));
    }
    return values;
}

struct ErrorMetrics {
    double max_abs_error;
    double mean_abs_error;
    double rmse;
    std::size_t max_error_index;
    bool passed;
};

ErrorMetrics compare_values(
    const std::string &name,
    const std::vector<float> &actual,
    const std::vector<float> &expected,
    double max_abs_tolerance) {
    if (actual.size() != expected.size()) {
        throw std::runtime_error("Size mismatch while comparing " + name);
    }

    double max_abs_error = 0.0;
    double absolute_error_sum = 0.0;
    double squared_error_sum = 0.0;
    std::size_t max_error_index = 0;
    for (std::size_t index = 0; index < actual.size(); ++index) {
        const double error =
            static_cast<double>(actual[index]) - static_cast<double>(expected[index]);
        const double absolute_error = std::fabs(error);
        absolute_error_sum += absolute_error;
        squared_error_sum += error * error;
        if (absolute_error > max_abs_error) {
            max_abs_error = absolute_error;
            max_error_index = index;
        }
    }

    ErrorMetrics metrics;
    metrics.max_abs_error = max_abs_error;
    metrics.mean_abs_error = absolute_error_sum / actual.size();
    metrics.rmse = std::sqrt(squared_error_sum / actual.size());
    metrics.max_error_index = max_error_index;
    metrics.passed = max_abs_error <= max_abs_tolerance;

    std::cout << std::left << std::setw(20) << name
              << " max_abs=" << std::scientific << std::setprecision(8)
              << metrics.max_abs_error
              << " mean_abs=" << metrics.mean_abs_error
              << " rmse=" << metrics.rmse
              << " tolerance=" << max_abs_tolerance
              << " max_index=" << metrics.max_error_index
              << " [" << (metrics.passed ? "PASS" : "FAIL") << "]\n";
    return metrics;
}

void require_shape(
    const std::string &name,
    const NpyFloatArray &array,
    const std::vector<std::size_t> &expected_shape) {
    if (array.shape != expected_shape) {
        throw std::runtime_error("Unexpected shape for " + name);
    }
}

#if !defined(LENET_HLS_TOP_CONV2)
bool run_conv1_checks(
    const std::string &model_root,
    std::vector<float> *pool1_for_downstream) {
    std::vector<float> input = load_text_floats(
        join_path(model_root, "Golden_Reference_For_HW/input_raw.txt"),
        lenet::INPUT_ELEMS);
    for (std::size_t index = 0; index < input.size(); ++index) {
        input[index] = (input[index] / 255.0f - 0.1307f) / 0.3081f;
    }

    const std::vector<float> conv1_weights = load_text_floats(
        join_path(model_root, "hw_weights/conv1.weight.txt"),
        lenet::CONV1_WEIGHT_ELEMS);
    const NpyFloatArray golden_conv1 = load_npy_float32(
        join_path(model_root, "hw_feature_maps/conv1.npy"));
    const NpyFloatArray golden_pool1 = load_npy_float32(
        join_path(model_root, "hw_feature_maps/pool1.npy"));

    require_shape("conv1", golden_conv1, {1, 6, 28, 28});
    require_shape("pool1", golden_pool1, {1, 6, 14, 14});

    std::vector<float> conv1_output(lenet::CONV1_OUT_ELEMS);
    std::vector<float> pool1_output(lenet::POOL1_OUT_ELEMS);
    lenet_conv1_top(
        input.data(), conv1_weights.data(), conv1_output.data());
    lenet::lenet_relu_pool1(conv1_output.data(), pool1_output.data());

    bool passed = true;
    passed &= compare_values(
        "Conv1 raw", conv1_output, golden_conv1.data, 2.0e-5).passed;
    passed &= compare_values(
        "ReLU+Pool1", pool1_output, golden_pool1.data, 2.0e-5).passed;

    if (pool1_for_downstream != 0) {
        *pool1_for_downstream = pool1_output;
    }
    return passed;
}
#endif

#if !defined(LENET_HLS_TOP_CONV1)
bool run_conv2_checks(
    const std::string &model_root,
    const std::vector<float> *pool1_from_conv1) {
    const std::vector<float> conv2_weights = load_text_floats(
        join_path(model_root, "hw_weights/conv2.weight.txt"),
        lenet::CONV2_WEIGHT_ELEMS);
    const NpyFloatArray golden_pool1 = load_npy_float32(
        join_path(model_root, "hw_feature_maps/pool1.npy"));
    const NpyFloatArray golden_conv2 = load_npy_float32(
        join_path(model_root, "hw_feature_maps/conv2.npy"));
    const NpyFloatArray golden_pool2 = load_npy_float32(
        join_path(model_root, "hw_feature_maps/pool2.npy"));

    require_shape("pool1", golden_pool1, {1, 6, 14, 14});
    require_shape("conv2", golden_conv2, {1, 16, 10, 10});
    require_shape("pool2", golden_pool2, {1, 16, 5, 5});

    std::vector<float> conv2_isolated_output(lenet::CONV2_OUT_ELEMS);
    lenet_conv2_top(
        golden_pool1.data.data(),
        conv2_weights.data(),
        conv2_isolated_output.data());

    bool passed = compare_values(
        "Conv2 isolated",
        conv2_isolated_output,
        golden_conv2.data,
        5.0e-3).passed;

    const std::vector<float> *pool2_input = &conv2_isolated_output;
    std::vector<float> conv2_end_to_end_output;
    if (pool1_from_conv1 != 0) {
        conv2_end_to_end_output.resize(lenet::CONV2_OUT_ELEMS);
        lenet_conv2_top(
            pool1_from_conv1->data(),
            conv2_weights.data(),
            conv2_end_to_end_output.data());
        passed &= compare_values(
            "Conv2 end-to-end",
            conv2_end_to_end_output,
            golden_conv2.data,
            5.0e-3).passed;
        pool2_input = &conv2_end_to_end_output;
    }

    std::vector<float> pool2_output(lenet::POOL2_OUT_ELEMS);
    lenet::lenet_relu_pool2(pool2_input->data(), pool2_output.data());
    passed &= compare_values(
        "ReLU+Pool2", pool2_output, golden_pool2.data, 5.0e-3).passed;
    return passed;
}
#endif

}  // namespace

int main(int argc, char **argv) {
    try {
        const std::string model_root = argc >= 2 ? argv[1] : "../model";

        std::cout << "LeNet-5 Conv1/Conv2 C simulation\n";
        std::cout << "Data layout: CHW feature maps, OIHW weights\n";
        std::cout << "Input preprocessing: (pixel/255 - 0.1307) / 0.3081\n";
        std::cout << "Golden conv maps are compared before ReLU.\n\n";

        bool all_passed = true;
#if defined(LENET_HLS_TOP_CONV1)
        std::cout << "Vivado HLS testbench mode: Conv1 only\n\n";
        all_passed = run_conv1_checks(model_root, 0);
#elif defined(LENET_HLS_TOP_CONV2)
        std::cout << "Vivado HLS testbench mode: Conv2 only\n\n";
        all_passed = run_conv2_checks(model_root, 0);
#else
        std::vector<float> pool1_output;
        all_passed = run_conv1_checks(model_root, &pool1_output);
        all_passed &= run_conv2_checks(model_root, &pool1_output);
#endif

        std::cout << "\nExpected label: 7 (member B input_raw.txt)\n";
        std::cout << "Overall result: " << (all_passed ? "PASS" : "FAIL") << "\n";
        return all_passed ? 0 : 1;
    } catch (const std::exception &error) {
        std::cerr << "Testbench error: " << error.what() << "\n";
        return 2;
    }
}
