#ifndef LENET_CONV_H_
#define LENET_CONV_H_

namespace lenet {

typedef float data_t;
typedef float weight_t;

constexpr int KERNEL_SIZE = 5;
constexpr int KERNEL_ELEMS = KERNEL_SIZE * KERNEL_SIZE;

constexpr int INPUT_C = 1;
constexpr int INPUT_H = 32;
constexpr int INPUT_W = 32;
constexpr int INPUT_ELEMS = INPUT_C * INPUT_H * INPUT_W;

constexpr int CONV1_OUT_C = 6;
constexpr int CONV1_OUT_H = 28;
constexpr int CONV1_OUT_W = 28;
constexpr int CONV1_OUT_ELEMS = CONV1_OUT_C * CONV1_OUT_H * CONV1_OUT_W;
constexpr int CONV1_WEIGHT_ELEMS = CONV1_OUT_C * INPUT_C * KERNEL_ELEMS;

constexpr int POOL1_OUT_C = 6;
constexpr int POOL1_OUT_H = 14;
constexpr int POOL1_OUT_W = 14;
constexpr int POOL1_OUT_ELEMS = POOL1_OUT_C * POOL1_OUT_H * POOL1_OUT_W;

constexpr int CONV2_OUT_C = 16;
constexpr int CONV2_OUT_H = 10;
constexpr int CONV2_OUT_W = 10;
constexpr int CONV2_OUT_ELEMS = CONV2_OUT_C * CONV2_OUT_H * CONV2_OUT_W;
constexpr int CONV2_WEIGHT_ELEMS =
    CONV2_OUT_C * POOL1_OUT_C * KERNEL_ELEMS;

constexpr int POOL2_OUT_C = 16;
constexpr int POOL2_OUT_H = 5;
constexpr int POOL2_OUT_W = 5;
constexpr int POOL2_OUT_ELEMS = POOL2_OUT_C * POOL2_OUT_H * POOL2_OUT_W;

// Validation utilities. Convolution outputs are deliberately left before
// ReLU so they can be compared directly with conv1.npy and conv2.npy.
void lenet_relu_pool1(
    const data_t input[CONV1_OUT_ELEMS],
    data_t output[POOL1_OUT_ELEMS]);

void lenet_relu_pool2(
    const data_t input[CONV2_OUT_ELEMS],
    data_t output[POOL2_OUT_ELEMS]);

}  // namespace lenet

// HLS top functions must be in the global namespace for Vivado HLS 2019.1
// C/RTL co-simulation wrapper generation. Feature maps use CHW order and
// weights use OIHW order, matching PyTorch Conv2d tensors.
extern "C" void lenet_conv1_top(
    const lenet::data_t input[lenet::INPUT_ELEMS],
    const lenet::weight_t weights[lenet::CONV1_WEIGHT_ELEMS],
    lenet::data_t output[lenet::CONV1_OUT_ELEMS]);

extern "C" void lenet_conv2_top(
    const lenet::data_t input[lenet::POOL1_OUT_ELEMS],
    const lenet::weight_t weights[lenet::CONV2_WEIGHT_ELEMS],
    lenet::data_t output[lenet::CONV2_OUT_ELEMS]);

#endif  // LENET_CONV_H_
