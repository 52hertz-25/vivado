# 成员 C：LeNet-5 Conv1/Conv2 Vivado HLS 2019.1 基线

本目录对应分工表中的成员 C 任务：实现 Conv1/Conv2、5×5 滑动窗口、MAC 计算，并使用成员 B 提供的权重和黄金特征图完成逐层验证。

## 已实现内容

- `lenet_conv1_top`：`1×32×32 -> 6×28×28`，5×5、stride=1、padding=0、无偏置。
- `lenet_conv2_top`：`6×14×14 -> 16×10×10`，5×5、stride=1、padding=0、无偏置。
- `generate_window_5x5`：按 CHW 特征图生成 5×5 滑动窗口。
- `mac_5x5`：窗口与 OIHW 权重的 25 项乘累加；Conv2 在 6 个输入通道上继续累加。
- `lenet_relu_pool1/2`：验证链路使用的 ReLU + 2×2 最大池化。
- C 仿真测试平台：读取 `input_raw.txt`、权重 txt 和 NumPy `.npy` 黄金结果，分别验证 Conv1、Pool1、隔离 Conv2、端到端 Conv2、Pool2。
- Vivado HLS 2019.1 Tcl：针对 XC7Z020 分别进行 C 仿真、C 综合、RTL 协同仿真并导出 Conv1/Conv2 IP。
- Windows 启动脚本：检查 `vivado_hls` 环境后自动运行完整 Tcl 流程。

## 数据与接口约定

- 特征图：CHW 行主序展平，索引为 `(channel * height + row) * width + col`。
- 权重：OIHW 行主序展平，与 PyTorch `Conv2d.weight` 及成员 B 的 txt 导出顺序一致。
- 输入预处理：`(pixel / 255.0 - 0.1307) / 0.3081`。
- 卷积输出不在顶层内部做 ReLU。成员 B 的 `conv1.npy`、`conv2.npy` 含负值，是 ReLU 之前的卷积结果；随后调用 ReLU/Pool 才与 `pool1.npy`、`pool2.npy` 比较。
- AXI 接口：输入、权重、输出位于三个独立的 `m_axi` bundle；控制端口使用 AXI4-Lite。

## 运行 C 仿真

在 PowerShell 中进入本目录后执行：

```powershell
.\run_csim.ps1
```

脚本使用 `g++` 编译并运行测试平台，结果保存到 `results/csim_results.txt`。默认模型目录是本目录旁边的 `../model`；也可以通过 `-ModelDir` 指定其他目录。

## 运行 Vivado HLS 2019.1

Xilinx 旧版工具对中文、空格路径的兼容性较差。建议把 `model` 和 `member_c_conv_hls` 一起复制到以下结构：

```text
D:\lenet_project\
├─ model\
└─ member_c_conv_hls\
```

打开开始菜单中的 **Vivado HLS 2019.1 Command Prompt**，先检查版本：

```text
vivado_hls -version
```

然后执行自动启动脚本：

```text
cd /d D:\lenet_project\member_c_conv_hls
run_vivado_hls_2019_1.bat
```

也可以直接执行 Tcl：

```text
vivado_hls -f run_hls.tcl
```

脚本采用 Vivado HLS 2019.1 语法，不使用新版 Vitis 的 `-flow_target` 参数。目标器件为任务书指定的 `xc7z020clg400-1`，目标时钟周期为 10 ns，并依次执行：

1. Conv1 C Simulation、C Synthesis 和 Verilog RTL Co-Simulation。
2. Conv2 C Simulation、C Synthesis 和 Verilog RTL Co-Simulation。

Vivado HLS 2014.x 至 2021.2 在 2022 年以后执行 IP 打包存在官方记录的 revision number overflow（Y2K22）问题。默认 `export_ip=0`，先保证成员 C 必需的仿真、综合、RTL 生成与资源报告完整完成。安装 AMD/Xilinx AR 76960 的 `y2k22_patch-1.2` 后，可将 `run_hls.tcl` 顶部的 `export_ip` 改为 `1` 再导出 IP。

两个顶层使用独立测试模式，RTL 协同仿真时只调用当前正在验证的顶层。输出位置如下：

```text
build\conv1_hls\solution1\syn\report\lenet_conv1_top_csynth.rpt
build\conv2_hls\solution1\syn\report\lenet_conv2_top_csynth.rpt

build\conv1_hls\solution1\sim\verilog\
build\conv2_hls\solution1\sim\verilog\

build\conv1_hls\solution1\syn\verilog\
build\conv2_hls\solution1\syn\verilog\
```

如果流程中途失败，先查看终端最早出现的 `ERROR:`，再查看对应工程的 `solution1` 日志。C 综合成功后即使后续 RTL 协同仿真或 IP 导出失败，`syn/report` 中的 HLS 综合报告通常仍会保留。

## 交给成员 D/E 的边界

- 本版本保留直观的单窗口、单 MAC 累加基线，便于成员 D 在相同接口上加入 `PIPELINE`、`UNROLL`、`ARRAY_PARTITION` 和 PE 阵列并做公平对比。
- 成员 E 可直接使用 Vivado HLS 2019.1 导出的两个 `*_top` AXI IP；如需系统级 DMA/AXI-Stream 包装，可在不改计算内核的情况下增加适配层。
- 量化不在本成员任务范围内；`data_t`/`weight_t` 集中定义在头文件中，后续可由成员 F 替换为 `ap_fixed`。

## 计算量

- Conv1：`6 × 28 × 28 × 1 × 25 = 117,600` MAC。
- Conv2：`16 × 10 × 10 × 6 × 25 = 240,000` MAC。
- 合计：`357,600` MAC。
