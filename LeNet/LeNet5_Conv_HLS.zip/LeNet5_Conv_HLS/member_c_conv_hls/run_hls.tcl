# Vivado HLS 2019.1 batch flow for LeNet-5 Conv1/Conv2.
# Run from "Vivado HLS 2019.1 Command Prompt" with:
#   vivado_hls -f run_hls.tcl

set root_dir [file dirname [file normalize [info script]]]
set model_dir [file normalize "$root_dir/../model"]
set part_name "xc7z020clg400-1"
set clock_period_ns 10.0
# Vivado HLS 2014.x-2021.2 needs AMD/Xilinx AR 76960 Y2K22 patch
# before IP packaging works after 2021. Keep this disabled until that patch is
# installed; C synthesis, RTL generation, and C/RTL co-simulation are unaffected.
set export_ip 0
set common_cflags "-std=c++11 -I$root_dir/include -I$root_dir/tb"

proc build_kernel {root_dir model_dir part_name clock_period_ns export_ip common_cflags kernel_name top_name} {
    # Vivado HLS 2019.1 treats the open_project argument as a project name and
    # rejects an absolute Windows path containing ':' or '/'. Enter the build
    # directory first, then create/open the project by its simple name.
    set build_dir [file normalize "$root_dir/build"]
    file mkdir $build_dir
    cd $build_dir
    open_project -reset "${kernel_name}_hls"
    set_top $top_name
    add_files "$root_dir/src/lenet_conv.cpp" -cflags $common_cflags

    if {$kernel_name eq "conv1"} {
        set tb_cflags "$common_cflags -DLENET_HLS_TOP_CONV1"
    } else {
        set tb_cflags "$common_cflags -DLENET_HLS_TOP_CONV2"
    }
    add_files -tb "$root_dir/tb/tb_lenet_conv.cpp" -cflags $tb_cflags

    # Vivado HLS 2019.1 does not use Vitis' -flow_target option.
    open_solution -reset "solution1"
    set_part $part_name
    create_clock -period $clock_period_ns -name default

    # The project is intentionally kept in an ASCII path without spaces.
    # Passing embedded quote characters makes Vivado HLS 2019.1 generate an
    # invalid ap_argv value such as ""D:/.../model"".
    csim_design -clean -argv $model_dir
    csynth_design
    cosim_design -rtl verilog -argv $model_dir

    if {$export_ip} {
        # Vivado HLS 2019.1 export_design has no Vitis-style -evaluate option.
        export_design -rtl verilog -format ip_catalog
    } else {
        puts "INFO: Skipping IP packaging; install AMD/Xilinx AR 76960 Y2K22 patch and set export_ip to 1 to enable it."
    }
    close_project
    cd $root_dir
}

build_kernel $root_dir $model_dir $part_name $clock_period_ns $export_ip $common_cflags \
    "conv1" "lenet_conv1_top"
build_kernel $root_dir $model_dir $part_name $clock_period_ns $export_ip $common_cflags \
    "conv2" "lenet_conv2_top"

exit
